## Licencia

MIT License 2025 - Jaime Silva