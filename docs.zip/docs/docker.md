## Docker

Cómo usar con Docker:
```bash
docker run ...
```