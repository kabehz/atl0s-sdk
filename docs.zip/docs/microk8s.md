## MicroK8s

Despliegue en Kubernetes local: