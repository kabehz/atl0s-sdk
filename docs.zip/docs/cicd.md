## CI/CD

Acciones automáticas en GitHub Actions.