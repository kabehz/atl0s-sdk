## Uso por CLI

```bash
python validador_service_v4.py ./entrada ./salida
```