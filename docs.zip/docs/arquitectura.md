# 🧠 Arquitectura del sistema

Grafo, BERT, Semantic NLP, Microservicios.